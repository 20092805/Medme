import React from 'react'
import "./MedmeHomiy.css"

const MedmeHomiy = () => {
  return (
    <div></div>
  )
}

export default MedmeHomiy