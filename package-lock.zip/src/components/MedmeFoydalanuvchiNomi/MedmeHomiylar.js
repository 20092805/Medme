import React from 'react'
import './MedmeHomiylar.css'

const MedmeHomiylar = () => {
    return (
        <div className='ContenierMedmeHomiylar'>
            <div className="MedmeHomiylar">
                <div className="MedmeHomiylarBolimi1">
                    <div className="MedmeHomiylarBolimizBox1"></div>
                    <div className="MedmeHomiylarBolimizBox2"></div>
                    <div className="MedmeHomiylarBolimizBox3"></div>
                    <div className="MedmeHomiylarBolimizBox4"></div>
                    <div className="MedmeHomiylarBolimizBox5"></div>
                    <div className="MedmeHomiylarBolimizBox6"></div>
                    <div className="MedmeHomiylarBolimizBox7"></div>
                    <div className="MedmeHomiylarBolimizBox8"></div>
                    <div className="MedmeHomiylarBolimizBox9"></div>
                </div>
                <div className="MedmeHomiylarBolimi2">
                    <div className="MedmeHomiylarBolimizBox1"></div>
                    <div className="MedmeHomiylarBolimizBox2"></div>
                    <div className="MedmeHomiylarBolimizBox3"></div>
                    <div className="MedmeHomiylarBolimizBox4"></div>
                    <div className="MedmeHomiylarBolimizBox5"></div>
                    <div className="MedmeHomiylarBolimizBox6"></div>
                    <div className="MedmeHomiylarBolimizBox7"></div>
                    <div className="MedmeHomiylarBolimizBox8"></div>
                    <div className="MedmeHomiylarBolimizBox9"></div>
                </div>
                <div className="MedmeHomiylarBolimi3">
                    <div className="MedmeHomiylarBolimizBox1"></div>
                    <div className="MedmeHomiylarBolimizBox2"></div>
                    <div className="MedmeHomiylarBolimizBox3"></div>
                    <div className="MedmeHomiylarBolimizBox4"></div>
                    <div className="MedmeHomiylarBolimizBox5"></div>
                    <div className="MedmeHomiylarBolimizBox6"></div>
                    <div className="MedmeHomiylarBolimizBox7"></div>
                    <div className="MedmeHomiylarBolimizBox8"></div>
                    <div className="MedmeHomiylarBolimizBox9"></div>
                </div>
                <div className="MedmeHomiylarBolimi4">
                    <div className="MedmeHomiylarBolimizBox1"></div>
                    <div className="MedmeHomiylarBolimizBox2"></div>
                    <div className="MedmeHomiylarBolimizBox3"></div>
                    <div className="MedmeHomiylarBolimizBox4"></div>
                    <div className="MedmeHomiylarBolimizBox5"></div>
                    <div className="MedmeHomiylarBolimizBox6"></div>
                    <div className="MedmeHomiylarBolimizBox7"></div>
                    <div className="MedmeHomiylarBolimizBox8"></div>
                    <div className="MedmeHomiylarBolimizBox9"></div>
                </div>
            </div>
        </div>
    )
}

export default MedmeHomiylar;