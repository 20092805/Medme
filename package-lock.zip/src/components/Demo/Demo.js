import React from 'react';
import './Demo.css';

const Demo = () => {
  return (
    <div className='DemoOlish'>
      <a href="#navbar">
      <button className='Demo'>Demo Olish</button>
      </a>
    </div>
  )
}

export default Demo

